## Keyword Extraction from the news feed or blogposts with IBM Cloud

This is a keyword extraction web application that is built on Flask.

[![Demonstration Video](https://img.youtube.com/vi/Xh556hFHO9s/hqdefault.jpg)](https://youtu.be/Xh556hFHO9s)
